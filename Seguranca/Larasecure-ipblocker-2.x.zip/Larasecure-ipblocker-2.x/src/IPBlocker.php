<?php

namespace Larasecure\IPBlocker;

class IPBlocker
{
    //
}