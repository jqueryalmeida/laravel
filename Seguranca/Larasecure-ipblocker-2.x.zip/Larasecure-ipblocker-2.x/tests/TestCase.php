<?php

namespace LaraSecure\IPBlocker\Tests;

use PHPUnit\Framework\TestCase as BaseTestCase;

class TestCase extends BaseTestCase
{
    /** @test */
    public function test()
    {
         $this->assertTrue(true);
    }
}