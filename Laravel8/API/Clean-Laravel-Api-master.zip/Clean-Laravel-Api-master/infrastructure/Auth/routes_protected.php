<?php

$router->post('/logout', 'LoginController@logout');
