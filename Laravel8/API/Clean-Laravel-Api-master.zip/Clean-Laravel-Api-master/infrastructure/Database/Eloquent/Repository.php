<?php

namespace Infrastructure\Database\Eloquent;

use one2tek\larapi\Database\Repository as BaseRepository;

abstract class Repository extends BaseRepository
{
}
