<?php

namespace Infrastructure\Http;

use Illuminate\Foundation\Validation\ValidatesRequests;
use one2tek\larapi\Controllers\LaravelController;

abstract class Controller extends LaravelController
{
}
